Multimap Patcher v1.8 - Windows
===============================

1. EXTRACT FIRST
   Unzip ALL files from MultimapPatcher-win.zip into a folder before
   running anything. Keep the "jre" folder next to MultimapPatcher.exe.
   Do NOT run the program from inside the zip file - it will not work.

2. RUN
   Double-click MultimapPatcher.exe.
   If Windows SmartScreen warns that it is from an unknown publisher,
   click "More info" and then "Run anyway".

3. IF NOTHING HAPPENS
   Double-click Run-Patcher.bat instead. It starts the program directly
   and skips the exe launcher.

4. IF THAT ALSO FAILS
   Double-click Run-Patcher-Debug.bat. A black window will stay open -
   take a photo of what it says and send it back.

WHAT IT DOES
   Load a 512 KB EDC15 flash BIN (file picker, or drag and drop it onto
   the window) to apply the Multimap switch and/or the flash Immo-off
   patch, or load a 512-byte 24C04 EEPROM dump to apply
   "Immo off (EEPROM)" or edit the SKC. Patches are grouped by file
   type so a flash patch can never be picked for an EEPROM dump.
   Your original file is never modified - the program always saves a
   new file.
   When the Multimap switch is applied, the three map slots are filled
   with the known-good blocks from the original multimap file so all
   maps and tables match; you tune each slot's maps afterwards.
   After Apply, the report shows what changed (map blocks / code /
   checksum stores) and the internal function test must pass before
   Save is enabled.
   "Verify checksums" checks the loaded flash file's checksums without
   applying any patch.
