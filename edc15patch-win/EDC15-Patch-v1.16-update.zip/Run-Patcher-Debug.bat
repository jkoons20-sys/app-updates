@echo off
rem Multimap Patcher - debug launcher. A black window stays open so any
rem error message is visible. If the program will not start, take a photo
rem of what this window says.
"%~dp0jre\bin\java.exe" -jar "%~dp0MultimapPatcher.jar"
echo.
echo ---- exit code: %ERRORLEVEL% ----
pause
