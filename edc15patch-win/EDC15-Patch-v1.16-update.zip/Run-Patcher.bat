@echo off
rem Multimap Patcher - direct launcher (bypasses MultimapPatcher.exe)
rem Uses the bundled JRE next to this file. No Java install needed.
start "" "%~dp0jre\bin\javaw.exe" -jar "%~dp0MultimapPatcher.jar"
