USB DEBUG v1.1 - README
======================

What this is
------------
A Windows tool that captures the USB traffic between diagnostic
software and your USB adapter/dongle, so the wire protocol can be
decoded. It does not talk to the ECU itself - it watches what the
software sends the adapter over USB.

Install (one time)
------------------
1. Extract this zip anywhere (e.g. C:\UsbDebug\).
2. Install USBPcap from https://desowin.org/usbpcap
   (the installer adds the capture driver; reboot if it asks).
3. Right-click UsbDebug.exe -> "Run as administrator".
   (USBPcap cannot capture without admin rights - the app will
   warn you if you forgot.)

Suggested capture order
-----------------------
Do these one at a time, each as its own labeled session:
  01-ecu-identify   - "ECU Identify" / read ECU info
  02-read-flash     - full flash read (the big one - takes a while)
  03-keepalive-idle - 60 seconds with the software open but idle
                      (shows keepalive / poll traffic, if any)
  04-write-flash    - only if you are already doing a real write

Capture steps (Tab 2)
---------------------
1. Plug in the USB adapter. Leave it plugged in for the whole session.
2. Tab 1 "Device": press "Scan USB devices".
   - Note the VID:PID - it tells us which capture path applies.
     Common serial bridges: FTDI (0403:6001), CH340 (1A86:7523),
     CH341 (1A86:5523), CP2102 (10C4:EA60).
3. Open the diagnostic software and get to just BEFORE the operation
   (e.g. the screen with the "Read" button, finger off the mouse).
4. Tab 2 "Capture": the USBPcap line should say "found".
   Pick the interface (usually USBPcap1), press "Refresh devices",
   pick the adapter's address from the list.
   Tip: press "Refresh devices" with the adapter unplugged, note the
   list, plug it in, refresh again - the new entry is the adapter.
5. Type a session label (e.g. 01-ecu-identify) and press
   "Start capture".
6. In the software, press the operation button. Wait until it fully
   finishes (read 100%, dialog closed).
7. Back here, press "Stop capture". The capture parses itself and
   saves to the sessions folder automatically.
   Tab 3 "Sessions" lists everything; "Export selected as zip"
   makes a zip of one session (capture.txt + capture.pcap).

Reading the results
-------------------
- Each session folder has capture.txt (readable text: timestamp,
  direction, endpoint, type, length, hex+ASCII) and capture.pcap
  (the raw capture - opens in Wireshark too).
- H->D = computer to adapter (a command), D->H = adapter to computer
  (a response). Packets are grouped: a command followed by its
  response(s) shares one "CMD group".
- Send the exported zip(s) back - that is the raw material the
  protocol work is built from.

If the adapter is a serial bridge
---------------------------------
FTDI/CH340/CP2102 adapters talk to the software through a virtual
COM port, so USBPcap still sees the traffic (USB bulk transfers
carrying the serial bytes). The capture steps above are identical.

Troubleshooting
---------------
- "USBPcap NOT found": install it (step 2 above), reboot, reopen app.
- "NOT running as Administrator": close, right-click, run as admin.
- "No capture data was written": USBPcapCMD could not start -
  usually the admin issue above, or the adapter was unplugged.
- "No devices on USBPcap1": the driver may need a reboot after
  install, or try another interface in the list.
- "Parse failed: Not a USBPcap file": the .pcap is corrupt or empty;
  re-run the capture.
- Antivirus/SmartScreen warning: the .exe is unsigned (normal for
  small tools) - "More info -> Run anyway".

Notes
-----
- The app never modifies your adapter, software, or ECU. Capture is
  read-only observation.
- Sessions are stored in the "sessions" folder next to the .exe.
