@echo off
cd /d %~dp0
start "" "UsbDebug.exe"
